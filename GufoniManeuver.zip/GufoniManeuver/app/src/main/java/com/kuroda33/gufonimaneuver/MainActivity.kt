package com.kuroda33.gufonimaneuver

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.preference.PreferenceManager
import android.util.Log
import com.kuroda33.gufonimaneuver.R.id.RCanal
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() , View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        RCanal.setOnClickListener(this)
        LCanal.setOnClickListener(this)
        RCupla.setOnClickListener(this)
        LCupla.setOnClickListener(this)
    }
    override fun onClick(v: View) {
        when(v.id){
            R.id.RCanal -> RCanal()
            R.id.LCanal -> LCanal()
            R.id.RCupla -> RCupla()
            R.id.LCupla -> LCupla()
        }
    }
    fun LCanal(){
        val intent= Intent(this,SecondActivity::class.java)
        intent.putExtra("LCa,RCa,LCu,RCu",0)
        startActivity(intent)
    }
    fun RCanal(){
        val intent= Intent(this,SecondActivity::class.java)
        intent.putExtra("LCa,RCa,LCu,RCu",1)
        startActivity(intent)
    }
    fun LCupla(){
        val intent= Intent(this,SecondActivity::class.java)
        intent.putExtra("LCa,RCa,LCu,RCu",2)
        startActivity(intent)
    }
    fun RCupla(){
        val intent= Intent(this,SecondActivity::class.java)
        intent.putExtra("LCa,RCa,LCu,RCu",3)
        startActivity(intent)
    }
 }
